"use strict";this.default_e=this.default_e||{};(function(_){var window=this;
try{
_.x("JnHVue");
var ayg=_.E("JnHVue");var byg=function(){_.CD.call(this)};_.M(byg,_.HD);byg.Ha=_.HD.Ha;byg.prototype.click=function(){_.kf(this.Aa().el(),"eA2Tkd")};byg.prototype.di=function(a){this.Aa().Ic("aria-label",a)};byg.prototype.$wa$cOuCgd=function(){return this.click};_.OD(ayg,byg);
_.y();
}catch(e){_._DumpException(e)}
}).call(this,this.default_e);
// Google Inc.
