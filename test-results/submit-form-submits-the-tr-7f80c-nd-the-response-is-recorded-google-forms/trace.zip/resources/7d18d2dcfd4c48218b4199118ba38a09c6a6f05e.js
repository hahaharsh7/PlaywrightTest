"use strict";this.default_e=this.default_e||{};(function(_){var window=this;
try{
_.x("AAf6tc");
var hRb;hRb={lWb:0,pOb:1,qOb:2};_.uF=function(a){_.Vy.call(this);this.O=new Map;this.N=new Map;this.W=this.H=null;this.pE=a.service.window};_.M(_.uF,_.Wy);_.uF.Ha=function(){return{service:{window:_.XA}}};_.k=_.uF.prototype;_.k.sAb=function(a,b){this.O.has(b);this.O.set(b,a)};_.k.Ufa=function(){var a;return(a=this.W)!=null?a:this.pE.Mc().body};
_.k.FZ=function(a,b,c,d,e,f){c=c===void 0?1:c;d=d===void 0?function(){}:d;e=e===void 0?function(){}:e;f=f===void 0?!0:f;this.O.has(a);var g=this.V();this.H!==null&&(this.N.set(this.H,Object.assign(this.N.get(this.H),{position:_.gy(_.ny(new _.ky(g),"position"),hRb,0)})),iRb(this,this.H,!1));var h=new _.$y;this.N.delete(a);this.N.set(a,{params:b,position:c,result:h});var m={TVa:-1};this.H=a;if(this.O.has(a)){var n=this.O.get(a);_.hf(g,"EtZTHe",{uAa:n,position:c,qK:a,NC:f,rFb:b,rAa:m,HAb:d,FAb:e})}return{Fdb:h.promise,
rAa:m}};_.k.uda=function(a,b){b=b===void 0?!1:b;this.O.has(a);iRb(this,a,b);this.N.delete(a);this.N.size===0?this.H=null:(a=Array.from(this.N.keys()).at(-1),this.H!==a&&(this.H=null,b=this.N.get(a),this.FZ(a,b.params,b.position)))};_.k.d0a=function(a){var b=this.V();_.gf(b,"tNt2pd",{qK:a})};var iRb=function(a,b,c){var d=a.V();_.gf(d,"Wzg5tf",{qK:b,dispose:c});var e;(e=a.N.get(b))==null||e.result.resolve()};
_.uF.prototype.reset=function(){this.H!==null&&iRb(this,this.H,!0);this.O.clear();this.N.clear();this.W=this.H=null};_.Bma(void 0,_.uF);
_.y();
}catch(e){_._DumpException(e)}
try{
_.x("samWqd");
_.vF=function(a){_.uF.call(this,a.Vb)};_.M(_.vF,_.uF);_.vF.Ha=_.uF.Ha;_.vF.prototype.V=function(){return this.Ufa().querySelector("[jsname=dr3XYe]")};_.Jg(_.otb,_.vF);
_.y();
}catch(e){_._DumpException(e)}
}).call(this,this.default_e);
// Google Inc.
